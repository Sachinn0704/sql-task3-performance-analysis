# SQL Advanced Student Performance Analysis (Task 3)

## Overview
Advanced SQL analysis using JOIN, GROUP BY, HAVING and aggregation.

## Files
- task3.sql
- README.md

## Queries
- Top student per course
- Pass rate per course
- Overall topper
- Students in multiple courses

## How to Run
1. Open SQL environment
2. Run task3.sql
3. Execute queries
