-- SQL Data Analysis Internship - Task 3

-- 1. Top student per course
SELECT c.name AS course, s.name AS student, MAX(e.grade) AS top_grade
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_id = c.id
GROUP BY c.name;

-- 2. Pass rate per course
SELECT c.name,
SUM(CASE WHEN e.grade >= 40 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS pass_rate
FROM enrollments e
JOIN courses c ON e.course_id = c.id
GROUP BY c.name;

-- 3. Overall topper
SELECT s.name, AVG(e.grade) AS avg_grade
FROM enrollments e
JOIN students s ON e.student_id = s.id
GROUP BY s.name
ORDER BY avg_grade DESC
LIMIT 1;

-- 4. Students in multiple courses
SELECT student_id, COUNT(course_id) AS total_courses
FROM enrollments
GROUP BY student_id
HAVING COUNT(course_id) > 1;
